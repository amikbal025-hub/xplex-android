# xPlex Android — Native source

xPlex is a native Android meme/sticker creation starter app built with Kotlin and Jetpack Compose.

## Current implemented features
- Three-slide first-launch onboarding (Done enters Home).
- Liquid Glass-inspired hybrid UI: translucent surfaces, rounded panels, soft blue/purple gradients.
- Home, Library, Meme Studio, and Settings screens.
- Import a photo using Android's system photo picker.
- Add a caption and preview it over the photo.
- Render and save the result as a PNG in `Pictures/xPlex`.
- Works offline after installation; imported images are processed locally.

## Android support
- `minSdk = 26` (Android 8.0 Oreo and newer).
- `targetSdk = 35`.
- Java 17 / Kotlin 2.0.21 / Android Gradle Plugin 8.7.3.

## Build locally
Open this folder in Android Studio, allow Gradle sync, then run the `app` configuration.

## Build with GitHub Actions
The repository workflow can unpack this source archive and run `gradle :app:assembleDebug`. The generated APK is at `app/build/outputs/apk/debug/app-debug.apk`.

## Scope note
This is a functional first implementation, not the entire long-term product. The Library screen currently points to the phone Gallery for saved PNGs; session counters reset when the app process restarts. Dedicated sticker-pack export, persistent in-app gallery indexing, font controls, and advanced cutout tools remain future work.
