package com.xplex.app

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.graphics.BitmapFactory

private val Ink = Color(0xFF20243A)
private val Muted = Color(0xFF777D96)
private val Purple = Color(0xFF7568D9)
private val Glass = Color(0xCCFFFFFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { XPlexApp() }
    }
}

@Composable
private fun XPlexApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("xplex", 0) }
    var showIntro by remember { mutableStateOf(!prefs.getBoolean("intro_done", false)) }
    var page by remember { mutableStateOf("home") }
    var selectedImage by remember { mutableStateOf<Bitmap?>(null) }
    var memeText by remember { mutableStateOf("WHEN THE WIFI WORKS") }
    var savedItems by remember { mutableStateOf(0) }
    var darkMode by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            runCatching { context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } }
                .onSuccess { selectedImage = it; page = "studio" }
                .onFailure { Toast.makeText(context, "Gagal membuka gambar", Toast.LENGTH_SHORT).show() }
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Purple, background = Color(0xFFF3F4FC))) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFF6F7FF), Color(0xFFE9EAF8), Color(0xFFF8F8FC))))) {
            when {
                showIntro -> Onboarding(onDone = { prefs.edit().putBoolean("intro_done", true).apply(); showIntro = false })
                page == "studio" -> StudioScreen(
                    bitmap = selectedImage,
                    text = memeText,
                    onTextChange = { memeText = it },
                    onBack = { page = "home" },
                    onPick = { picker.launch("image/*") },
                    onSave = {
                        val bmp = selectedImage
                        if (bmp == null) Toast.makeText(context, "Pilih gambar dulu", Toast.LENGTH_SHORT).show()
                        else {
                            val result = renderMeme(bmp, memeText)
                            val values = ContentValues().apply {
                                put(MediaStore.Images.Media.DISPLAY_NAME, "xPlex_${System.currentTimeMillis()}.png")
                                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/xPlex")
                            }
                            val saved = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                            val ok = saved?.let { context.contentResolver.openOutputStream(it)?.use { stream -> result.compress(Bitmap.CompressFormat.PNG, 100, stream) } } ?: false
                            if (ok) { savedItems++; Toast.makeText(context, "Meme tersimpan di Pictures/xPlex", Toast.LENGTH_LONG).show() }
                            else Toast.makeText(context, "Gagal menyimpan gambar", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
                page == "library" -> LibraryScreen(savedItems, onBack = { page = "home" }, onCreate = { picker.launch("image/*") })
                page == "settings" -> SettingsScreen(darkMode, { darkMode = it }, onBack = { page = "home" })
                else -> HomeScreen(
                    onCreate = { picker.launch("image/*") },
                    onLibrary = { page = "library" },
                    onSettings = { page = "settings" },
                    onStudio = { page = "studio" },
                    savedItems = savedItems
                )
            }
        }
    }
}

@Composable
private fun Onboarding(onDone: () -> Unit) {
    var index by remember { mutableIntStateOf(0) }
    val titles = listOf("Meme, made yours.", "Turn moments into memes.", "Create. Save. Share.")
    val desc = listOf("Semua ide lucu kamu, mulai dari satu gambar.", "Tambahkan teks meme dan atur hasilnya dengan mudah.", "Simpan hasil sebagai PNG langsung ke galeri.")
    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
        Spacer(Modifier.height(20.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(230.dp).clip(RoundedCornerShape(54.dp)).background(Brush.linearGradient(listOf(Color(0xFFB9B7FF), Color(0xFFE4DFFF), Color(0xFFB7DFFF)))), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("xP", fontSize = 72.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text("PLEX", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White, letterSpacing = 6.sp)
                }
            }
            Spacer(Modifier.height(38.dp))
            Text(titles[index], fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Ink, textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Text(desc[index], fontSize = 15.sp, color = Muted, textAlign = TextAlign.Center, lineHeight = 23.sp)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { repeat(3) { i -> Box(Modifier.width(if (i == index) 24.dp else 7.dp).height(7.dp).clip(CircleShape).background(if (i == index) Purple else Color(0xFFD3D4E3))) } }
            Spacer(Modifier.height(24.dp))
            Button(onClick = { if (index < 2) index++ else onDone() }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(20.dp)) { Text(if (index == 2) "Done" else "Continue", fontWeight = FontWeight.Bold) }
            TextButton(onClick = onDone) { Text("Skip", color = Muted) }
        }
    }
}

@Composable
private fun HomeScreen(onCreate: () -> Unit, onLibrary: () -> Unit, onSettings: () -> Unit, onStudio: () -> Unit, savedItems: Int) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp)) {
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column { Text("xPlex", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Ink); Text("Your little meme workshop", color = Muted, fontSize = 13.sp) }
            Box(Modifier.size(46.dp).clip(CircleShape).background(Glass).border(1.dp, Color.White, CircleShape), contentAlignment = Alignment.Center) { Text("xP", color = Purple, fontWeight = FontWeight.Black) }
        }
        Spacer(Modifier.height(28.dp))
        Box(Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(30.dp)).background(Brush.linearGradient(listOf(Color(0xFF8279E8), Color(0xFFB5A9F4), Color(0xFF8DC5E8)))).padding(22.dp)) {
            Column(Modifier.align(Alignment.CenterStart)) {
                Text("MAKE IT\nA MEME.", fontSize = 31.sp, lineHeight = 34.sp, color = Color.White, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(12.dp))
                Text("Your photo. Your punchline.", color = Color.White.copy(alpha = .9f), fontSize = 13.sp)
            }
            Text("😂", fontSize = 64.sp, modifier = Modifier.align(Alignment.BottomEnd))
        }
        Spacer(Modifier.height(25.dp))
        Text("Create something", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ActionCard("Meme Studio", "Edit photo + text", "✦", Modifier.weight(1f), onCreate)
            ActionCard("Sticker Lab", "Start from image", "▧", Modifier.weight(1f), onCreate)
        }
        Spacer(Modifier.height(25.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text("Your library", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink); TextButton(onClick = onLibrary) { Text("See all") } }
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Glass).border(1.dp, Color.White, RoundedCornerShape(24.dp)).padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(54.dp).clip(RoundedCornerShape(17.dp)).background(Color(0xFFE6E4FF)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Collections, null, tint = Purple) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) { Text("Saved creations", color = Ink, fontWeight = FontWeight.SemiBold); Text("$savedItems item${if (savedItems == 1) "" else "s"} in this session", color = Muted, fontSize = 12.sp) }
                Icon(Icons.Default.ArrowBack, null, tint = Muted, modifier = Modifier.clickable { onLibrary() })
            }
        }
        Spacer(Modifier.height(28.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Glass).padding(8.dp), horizontalArrangement = Arrangement.SpaceAround) {
            NavItem("Home", Icons.Default.Home, true) {}
            NavItem("Library", Icons.Default.Collections, false, onLibrary)
            NavItem("Settings", Icons.Default.Settings, false, onSettings)
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, symbol: String, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(24.dp)).background(Glass).border(1.dp, Color.White, RoundedCornerShape(24.dp)).clickable { onClick() }.padding(17.dp)) {
        Box(Modifier.size(43.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFE9E7FF)), contentAlignment = Alignment.Center) { Text(symbol, color = Purple, fontSize = 25.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(17.dp)); Text(title, color = Ink, fontWeight = FontWeight.Bold); Spacer(Modifier.height(4.dp)); Text(subtitle, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun NavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(16.dp)).clickable { onClick() }.padding(horizontal = 15.dp, vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null, tint = if (selected) Purple else Muted); Text(label, fontSize = 10.sp, color = if (selected) Purple else Muted) }
}

@Composable
private fun StudioScreen(bitmap: Bitmap?, text: String, onTextChange: (String) -> Unit, onBack: () -> Unit, onPick: () -> Unit, onSave: () -> Unit) {
    var editing by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Ink) }; Text("Meme Studio", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink) }
        Spacer(Modifier.height(16.dp))
        Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(26.dp)).background(Color(0xFFE1E2EF)), contentAlignment = Alignment.Center) {
            if (bitmap != null) {
                Image(bitmap.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                Text(text, Modifier.align(Alignment.TopCenter).padding(16.dp).background(Color.Black.copy(alpha = .55f), RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 6.dp), color = Color.White, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, fontSize = 21.sp)
            } else Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Image, null, tint = Muted, modifier = Modifier.size(54.dp)); Text("Your canvas is waiting", color = Ink, fontWeight = FontWeight.Bold); Text("Import a photo to start", color = Muted, fontSize = 13.sp) }
        }
        Spacer(Modifier.height(15.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = onPick, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(17.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add photo") }
            Button(onClick = { editing = true }, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(17.dp)) { Text("Edit text") }
        }
        Spacer(Modifier.height(10.dp))
        Button(onClick = onSave, enabled = bitmap != null, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(8.dp)); Text("Save as PNG") }
    }
    if (editing) AlertDialog(onDismissRequest = { editing = false }, title = { Text("Meme caption") }, text = { OutlinedTextField(value = text, onValueChange = onTextChange, label = { Text("Your text") }, minLines = 2) }, confirmButton = { TextButton(onClick = { editing = false }) { Text("Done") } })
}

@Composable
private fun LibraryScreen(savedItems: Int, onBack: () -> Unit, onCreate: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }; Text("Library", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink) }
        Spacer(Modifier.height(20.dp))
        if (savedItems == 0) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("▧", fontSize = 55.sp, color = Purple); Text("Nothing here yet", fontWeight = FontWeight.Bold, color = Ink, fontSize = 19.sp); Text("Your saved creations will appear in Gallery.", color = Muted, textAlign = TextAlign.Center); Spacer(Modifier.height(18.dp)); Button(onClick = onCreate) { Text("Create your first meme") } } }
        } else {
            Text("$savedItems creation(s) saved during this session", color = Muted)
            Spacer(Modifier.height(12.dp))
            Text("Open your phone Gallery → Pictures → xPlex to view your PNG files.", color = Ink)
        }
    }
}

@Composable
private fun SettingsScreen(darkMode: Boolean, onDarkMode: (Boolean) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }; Text("Settings", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink) }
        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Glass).padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Dark appearance", color = Ink, fontWeight = FontWeight.SemiBold); Text("UI appearance preference", color = Muted, fontSize = 12.sp) }; Switch(checked = darkMode, onCheckedChange = onDarkMode) }
        Spacer(Modifier.height(18.dp))
        Text("xPlex 1.0.0", color = Ink, fontWeight = FontWeight.Bold)
        Text("Made for your everyday creativity.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        Text("Note: this first source release saves PNG creations locally. Advanced sticker-pack export and animated effects are not included yet.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

private fun renderMeme(source: Bitmap, caption: String): Bitmap {
    val output = source.copy(Bitmap.Config.ARGB_8888, true)
    val canvas = AndroidCanvas(output)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AndroidColor.WHITE; textAlign = Paint.Align.CENTER; typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD); textSize = (output.width * 0.075f).coerceAtMost(110f); setShadowLayer(5f, 2f, 2f, AndroidColor.BLACK); strokeWidth = 5f }
    val maxWidth = output.width * .9f
    val words = caption.uppercase().split(" ")
    val lines = mutableListOf<String>(); var line = ""
    for (word in words) { val test = if (line.isEmpty()) word else "$line $word"; if (paint.measureText(test) > maxWidth && line.isNotEmpty()) { lines.add(line); line = word } else line = test }
    if (line.isNotEmpty()) lines.add(line)
    var y = output.height * .11f
    for (item in lines.take(4)) { canvas.drawText(item, output.width / 2f, y, paint); y += paint.textSize * 1.15f }
    return output
}
